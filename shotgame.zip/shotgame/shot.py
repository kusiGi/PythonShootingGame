import pygame
import random
import sys
import os

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("2D Shooting Game")

clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 36)
big_font = pygame.font.SysFont(None, 72)

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (80, 180, 255)
RED = (255, 80, 80)
GREEN = (80, 255, 120)
YELLOW = (255, 255, 100)
GRAY = (180, 180, 180)

# 画像読み込み
base_path = os.path.dirname(__file__)

player_path = os.path.join(base_path, "player.png")
enemy_path  = os.path.join(base_path, "enemy.png")
bg_path     = os.path.join(base_path, "bg.png")

player_img = pygame.image.load(player_path).convert_alpha()
enemy_img  = pygame.image.load(enemy_path).convert_alpha()
bg_img     = pygame.image.load(bg_path).convert()

player_img = pygame.transform.scale(player_img, (55, 55))
enemy_img  = pygame.transform.scale(enemy_img, (55, 55))
bg_img     = pygame.transform.scale(bg_img, (WIDTH, HEIGHT))

bg_y1 = 0
bg_y2 = -HEIGHT
bg_speed = 2

# サイズ調整
player_img = pygame.transform.scale(player_img, (55, 55))
enemy_img = pygame.transform.scale(enemy_img, (55, 55))

# プレイヤー設定
player_width = 55
player_height = 55
player_x = WIDTH // 2 - player_width // 2
player_y = HEIGHT - 140
player_speed = 6
player_max_hp = 100
player_hp = 100

# 弾設定
bullets = []
bullet_width = 6
bullet_height = 14
bullet_speed = 8

# 連射制限
shoot_cooldown = 12
shoot_timer = 0

# 敵設定
enemies = []
enemy_width = 55
enemy_height = 55
enemy_speed_min = 2
enemy_speed_max = 5
enemy_spawn_timer = 0
enemy_spawn_interval = 40   # 小さいほどたくさん出る

# 敵弾設定
enemy_bullets = []
enemy_bullet_width = 6
enemy_bullet_height = 14
enemy_bullet_speed = 8

# スコア
score = 0

# ゲーム状態
game_over = False


def draw_player(x, y):
    screen.blit(player_img, (x, y))


def draw_enemy(enemy):
    x, y, speed, enemy_shoot_timer = enemy
    screen.blit(enemy_img, (x, y))


def draw_bullet(bullet):
    pygame.draw.rect(screen, YELLOW, bullet)


def draw_enemy_bullet(bullet):
    pygame.draw.rect(screen, GREEN, bullet)


def draw_text(text, font_obj, color, x, y):
    img = font_obj.render(text, True, color)
    screen.blit(img, (x, y))

def draw_hp_bar(x, y, width, height, hp, max_hp):
    ratio = hp / max_hp
    pygame.draw.rect(screen, WHITE, (x, y, width, height), 2)  # 枠
    pygame.draw.rect(screen, GREEN, (x, y, width * ratio, height))  # 中身


def reset_game():
    global player_x, player_y, player_hp, bullets, enemies, enemy_bullets
    global score, game_over, enemy_spawn_timer, shoot_timer

    player_x = WIDTH // 2 - player_width // 2
    player_y = HEIGHT - 140
    player_hp = 100
    bullets = []
    enemies = []
    enemy_bullets = []
    score = 0
    game_over = False
    enemy_spawn_timer = 0
    shoot_timer = 0


while True:
    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if game_over:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    reset_game()
    
    bg_y1 += bg_speed -1
    bg_y2 += bg_speed -1

    if bg_y1 >= HEIGHT:
        bg_y1 = -HEIGHT

    if bg_y2 >= HEIGHT:
        bg_y2 = -HEIGHT

    keys = pygame.key.get_pressed()

    if not game_over:
        # プレイヤー移動
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < WIDTH - player_width:
            player_x += player_speed

        # 発射タイマー更新
        if shoot_timer > 0:
            shoot_timer -= 1

        # スペース長押しで左右2連射
        if keys[pygame.K_SPACE] and shoot_timer == 0:
            left_bullet = pygame.Rect(
                player_x + 8,
                player_y,
                bullet_width,
                bullet_height
            )
            right_bullet = pygame.Rect(
                player_x + player_width - 8 - bullet_width,
                player_y,
                bullet_width,
                bullet_height
            )

            bullets.append(left_bullet)
            bullets.append(right_bullet)

            shoot_timer = shoot_cooldown

        # 弾移動
        for bullet in bullets[:]:
            bullet.y -= bullet_speed
            if bullet.y < 0:
                bullets.remove(bullet)

        # 敵出現
        enemy_spawn_timer += 1
        if enemy_spawn_timer >= enemy_spawn_interval:
            ex = random.randint(0, WIDTH - enemy_width)
            ey = -enemy_height
            espeed = random.randint(enemy_speed_min, enemy_speed_max)
            enemy_shoot_timer = random.randint(30, 120)
            enemies.append([ex, ey, espeed, enemy_shoot_timer])
            enemy_spawn_timer = 0

        # 敵移動と射撃
        for enemy in enemies[:]:
            enemy[1] += enemy[2]
            enemy[3] -= 1

            if enemy[3] <= 0:
                eb = pygame.Rect(
                    enemy[0] + enemy_width // 2 - enemy_bullet_width // 2,
                    enemy[1] + enemy_height,
                    enemy_bullet_width,
                    enemy_bullet_height
                )
                enemy_bullets.append(eb)
                enemy[3] = random.randint(60, 140)

            if enemy[1] > HEIGHT:
                enemies.remove(enemy)

        # 敵弾移動
        for eb in enemy_bullets[:]:
            eb.y += enemy_bullet_speed
            if eb.y > HEIGHT:
                enemy_bullets.remove(eb)

        # 当たり判定（自弾 vs 敵）
        for bullet in bullets[:]:
            hit = False
            for enemy in enemies[:]:
                enemy_rect = pygame.Rect(enemy[0], enemy[1], enemy_width, enemy_height)
                if bullet.colliderect(enemy_rect):
                    if bullet in bullets:
                        bullets.remove(bullet)
                    if enemy in enemies:
                        enemies.remove(enemy)
                    score += 100
                    hit = True
                    break
            if hit:
                continue

        # 当たり判定（敵弾 vs プレイヤー）
        player_rect = pygame.Rect(player_x, player_y, player_width, player_height)
        for eb in enemy_bullets[:]:
            if eb.colliderect(player_rect):
                enemy_bullets.remove(eb)
                player_hp -= 20
                if player_hp <= 0:
                    game_over = True

        # 当たり判定（敵本体 vs プレイヤー）
        for enemy in enemies[:]:
            enemy_rect = pygame.Rect(enemy[0], enemy[1], enemy_width, enemy_height)
            if enemy_rect.colliderect(player_rect):
                enemies.remove(enemy)
                player_hp -= 20
                if player_hp <= 0:
                    game_over = True

        # 描画
    # 背景（最初に描く）
    screen.blit(bg_img, (0, bg_y1))
    screen.blit(bg_img, (0, bg_y2))

    if not game_over:
        draw_player(player_x, player_y)

        for bullet in bullets:
            draw_bullet(bullet)

        for enemy in enemies:
            draw_enemy(enemy)

        for eb in enemy_bullets:
            draw_enemy_bullet(eb)

        # UI（下配置）
        draw_hp_bar(20, HEIGHT - 80, 200, 20, player_hp, player_max_hp)
        draw_text(f"HP: {player_hp}/{player_max_hp}", font, WHITE, 20, HEIGHT - 55)

        draw_text(f"Score: {score}", font, WHITE, 20, HEIGHT - 30)

        draw_text("Move: <- ->", font, WHITE, WIDTH - 220, HEIGHT - 60)
        draw_text("Shoot: SPACE", font, WHITE, WIDTH - 220, HEIGHT - 40)

    else:
        draw_text("GAME OVER", big_font, WHITE, WIDTH // 2 - 170, HEIGHT // 2 - 80)
        draw_text(f"Score: {score}", font, WHITE, WIDTH // 2 - 60, HEIGHT // 2 + 10)
        draw_text("Press R to Restart", font, WHITE, WIDTH // 2 - 110, HEIGHT // 2 + 50)

    pygame.display.flip()    # 描画
    

    if not game_over:
        draw_player(player_x, player_y)

        for bullet in bullets:
            draw_bullet(bullet)

        for enemy in enemies:
            draw_enemy(enemy)

        for eb in enemy_bullets:
            draw_enemy_bullet(eb)

        # UI（下配置）
        draw_hp_bar(20, HEIGHT - 80, 200, 20, player_hp, player_max_hp)
        draw_text(f"HP: {player_hp}/{player_max_hp}", font, WHITE, 20, HEIGHT - 55)

        draw_text(f"Score: {score}", font, WHITE, 20, HEIGHT - 30)

        draw_text("Move: <- ->", font, WHITE, WIDTH - 220, HEIGHT - 60)
        draw_text("Shoot: SPACE", font, WHITE, WIDTH - 220, HEIGHT - 40)

    else:
        draw_text("GAME OVER", big_font, WHITE, WIDTH // 2 - 170, HEIGHT // 2 - 80)
        draw_text(f"Score: {score}", font, WHITE, WIDTH // 2 - 60, HEIGHT // 2 + 10)
        draw_text("Press R to Restart", font, WHITE, WIDTH // 2 - 110, HEIGHT // 2 + 50)

    pygame.display.flip()